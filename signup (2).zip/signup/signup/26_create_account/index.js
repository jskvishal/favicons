const Koa = require('koa');
const axios = require('axios');
var Router = require('koa-router');
const app = new Koa();
var router = Router();
const serve = require('koa-static');
app.use(serve('./public'));
// const authuser = require('./public/app');
const API_URL = 'http://localhost:8081/api/auth/';
app.listen(3000);
router.get('/confirm/:confirmationCode', async (ctx) => {
  const code = ctx.params.confirmationCode;
  return axios.get(API_URL + 'confirm/' + code).then((response) => {
    return response.data;
  });
});
console.log('listening on port 3000');
app.use(router.routes()).use(router.allowedMethods());

const dsteem = require('dsteem');
const axios = require('axios');
const Swal = require('sweetalert2');
const API_URL = 'http://localhost:8081/api/auth/';
// getting environment variable
const creatorUser = process.env.userCreator;
const active_Key = process.env.active_key;
let opts = {};
//connect to production server
opts.addressPrefix = 'WTH';
opts.chainId =
  'd909c4dfab0369c4ae4f4acaf2229cc1e49b3bba0dffb36a37b6174a6f391e2e';
//connect to server which is connected to the network/production
const client = new dsteem.Client('https://api.wortheum.news');

// const dsteem = require('dsteem');
// //define network parameters
// let opts = {};
// opts.addressPrefix = 'STX';
// opts.chainId =
//     '79276aea5d4877d9a25892eaa01b0adf019d3e5cb12a97478df3298ccdd01673';
// //connect to a steem node, testnet in this case
// const client = new dsteem.Client('https://testnet.steem.vc', opts);

//submit Account search function from html input
const max = 5;
window.searchAcc = async () => {
  const accSearch = document.getElementById('username').value;
  let avail = 'Account is not available to register';
  let infocolor = 'red';
  if (accSearch == '') {
    avail = '* Required field';
  }
  if (accSearch.length > 2) {
    const _account = await client.database.call('get_accounts', [[accSearch]]);
    console.log(`_account:`, _account, accSearch.length);

    if (_account.length == 0) {
      avail = 'Account is available to register';
      infocolor = '#999';
    }
  }
  document.getElementById('accInfo').style.color = infocolor;
  document.getElementById('accInfo').innerHTML = avail;
};

//create with STEEM function
window.submitTx = async () => {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  const ownerKey = dsteem.PrivateKey.fromLogin(username, password, 'owner');
  const activeKey = dsteem.PrivateKey.fromLogin(username, password, 'active');
  const postingKey = dsteem.PrivateKey.fromLogin(username, password, 'posting');
  const memoKey = dsteem.PrivateKey.fromLogin(
    username,
    password,
    'memo'
  ).createPublic(opts.addressPrefix);

  const ownerAuth = {
    weight_threshold: 1,
    account_auths: [],
    key_auths: [[ownerKey.createPublic(opts.addressPrefix), 1]],
  };
  const activeAuth = {
    weight_threshold: 1,
    account_auths: [],
    key_auths: [[activeKey.createPublic(opts.addressPrefix), 1]],
  };
  const postingAuth = {
    weight_threshold: 1,
    account_auths: [],
    key_auths: [[postingKey.createPublic(opts.addressPrefix), 1]],
  };

  const privateKey = dsteem.PrivateKey.fromString(active_Key);

  const op = [
    'account_create',
    {
      fee: '1.000 WORTH',
      creator: creatorUser,
      new_account_name: username,
      owner: ownerAuth,
      active: activeAuth,
      posting: postingAuth,
      memo_key: memoKey,
      json_metadata: '',
    },
  ];

  client.broadcast.sendOperations([op], privateKey).then(
    function (result) {
      let res = `Included in block: ${result.block_num}`;
      Swal.fire('Good job!', res, 'success');
    },
    function (error) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: error,
      });
      console.error(error);
    }
  );
};

//create with RC function
window.submitDisc = async () => {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  //create keys
  const ownerKey = dsteem.PrivateKey.fromLogin(username, password, 'owner');
  const activeKey = dsteem.PrivateKey.fromLogin(username, password, 'active');
  const postingKey = dsteem.PrivateKey.fromLogin(username, password, 'posting');
  const memoKey = dsteem.PrivateKey.fromLogin(
    username,
    password,
    'memo'
  ).createPublic(opts.addressPrefix);

  const ownerAuth = {
    weight_threshold: 1,
    account_auths: [],
    key_auths: [[ownerKey.createPublic(opts.addressPrefix), 1]],
  };
  const activeAuth = {
    weight_threshold: 1,
    account_auths: [],
    key_auths: [[activeKey.createPublic(opts.addressPrefix), 1]],
  };
  const postingAuth = {
    weight_threshold: 1,
    account_auths: [],
    key_auths: [[postingKey.createPublic(opts.addressPrefix), 1]],
  };

  //private active key of creator account
  const privateKey = dsteem.PrivateKey.fromString(active_Key);

  let ops = [];

  //claim discounted account operation
  const creator = document.getElementById('account').value;
  const _account = await client.database.call('get_accounts', [[creator]]);
  console.log(
    'current pending claimed accounts: ' + _account[0].pending_claimed_accounts
  );
  if (_account[0].pending_claimed_accounts == 0) {
    const claim_op = [
      'claim_account',
      {
        creator: creator,
        fee: '0.000 WORTH',
        extensions: [],
      },
    ];
    console.log('You have claimed a token');
    ops.push(claim_op);
  }

  //create operation to transmit
  const create_op = [
    'create_claimed_account',
    {
      creator: creatorUser,
      new_account_name: username,
      owner: ownerAuth,
      active: activeAuth,
      posting: postingAuth,
      memo_key: memoKey,
      json_metadata: '',
      extensions: [],
    },
  ];
  ops.push(create_op);

  //broadcast operation to blockchain
  client.broadcast.sendOperations(ops, privateKey).then(
    function (result) {
      document.getElementById('result').style.display = 'block';
      document.getElementById(
        'result'
      ).innerHTML = `<br/><p>Included in block: ${result.block_num}</p><br/><br/>`;
    },
    function (error) {
      console.error(error);
    }
  );
};

// Creates a suggested password
function suggestPassword() {
  const array = new Uint32Array(10);
  window.crypto.getRandomValues(array);
  return 'P' + dsteem.PrivateKey.fromSeed(array).toString();
}
window.onload = function (e) {
  document.getElementById('password').value = suggestPassword();
};

//register api

const register = (username, email, phoneNumber) => {
  return axios.post(API_URL + 'signup', {
    username,
    email,
    phoneNumber,
  });
};

const login = (username, password) => {
  return axios
    .post(API_URL + 'signin', {
      username,
      password,
    })
    .then((response) => {
      if (response.data.accessToken) {
        localStorage.setItem('user', JSON.stringify(response.data));
      }
      return response.data;
    });
};
const Usercheck = (username, email, phoneNumber) => {
  if (username == '') {
    document.getElementById('accInfo').style.color = 'red';
    document.getElementById('accInfo').innerHTML = '* Required field';
    return false;
  }
  if (email == '') {
    document.getElementById('email-error').style.color = 'red';
    document.getElementById('email-error').innerHTML = '* Required field  ';
    return false;
  }
  if (phoneNumber == '') {
    document.getElementById('phone-error').style.color = 'red';
    document.getElementById('phone-error').innerHTML = '* Required field ';
    return false;
  }
};

window.RegisterUser = async () => {
  const username = document.getElementById('username').value;
  const email = document.getElementById('email').value;
  const phoneNumber = document.getElementById('phoneNo').value;
  if (username) {
    document.getElementById('accInfo').style.display = 'none';
  }
  if (email) {
    document.getElementById('email-error').style.display = 'none';
  }
  if (phoneNumber) {
    document.getElementById('phone-error').style.display = 'none';
  }
  if (username.length > 2 && email != '' && phoneNumber != '') {
    await register(username, email, phoneNumber).then(
      (response) => {
        Swal.fire(response.data.message);
      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: resMessage,
        });
      }
    );
  } else {
    const checker = Usercheck(username, email, phoneNumber);
    if (checker == false) {
      return false;
    }
  }
};

window.SubmitUser = async () => {
  const username = document.getElementById('username').value;
  const phoneNumber = document.getElementById('phoneNo').value;
  const email = document.getElementById('email').value;
  const ischecked = document.getElementById('key-checker');
  if (!ischecked.checked) {
    document.getElementById('ischecked').innerHTML =
      '* Please confirm the above line to continue';
    return false;
  } else {
    document.getElementById('ischecked').style.display = 'none';
  }
  if (username.length > 2 && email && phoneNumber) {
    await login(username, phoneNumber).then(
      () => {
        submitTx();
      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();

        Swal.fire('Email Verification?', resMessage, 'question');
      }
    );
  } else {
    const checker = Usercheck(username, email, phoneNumber);
    if (checker == false) {
      return false;
    }
  }
};
